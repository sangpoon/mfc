#include <stdio.h>
#include "math.h"
int main() {
CMath me(5, 3);
printf("%d\\n", me.Add());
return 0;
}