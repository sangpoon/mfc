#include<afxwin.h>

class CMyFrm : public CFrameWnd {

public:

	CMyFrm() {

		Create(NULL, L"Hi !");

	}

	DECLARE_MESSAGE_MAP()
	afx_msg void OnPaint();
};

class CMy : public CWinApp {

	BOOL InitInstance() {

		CMyFrm* Frm = new CMyFrm();

		m_pMainWnd = Frm;

		Frm->ShowWindow(1);

		return TRUE;

	}

};

CMy theApp;
BEGIN_MESSAGE_MAP(CMyFrm, CFrameWnd)
	ON_WM_PAINT()
END_MESSAGE_MAP()

#include <atlimage.h>
#include <afxdlgs.h>
CString str;
void CMyFrm::OnPaint()
{
	CImage img;
	
	CPaintDC dc(this);
	img.Load(L"ANU.jpg");
	img.Draw(dc, 0, 0);
}
